#ifndef logika
#define logika

void hitungSkor(int i);
void simpanFile();
void muatFile();

#endif 