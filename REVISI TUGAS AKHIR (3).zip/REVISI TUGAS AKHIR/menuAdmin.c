#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "struktur.h"
#include "helper.h"
#include "admin.h"
#include "fiturAdmin.h"

void menuAdmin() {
    int pil;
    do {
        bersihkanLayar();
        printf("=== ADMIN DASHBOARD ===\n");
        printf("1. Input Data Warga\n");
        printf("2. Edit Data \n");
        printf("3. Hapus Data\n");
        printf("4. Tampil Semua Data\n");
        printf("5. Data Bansos\n");
        printf("6. Cek Kotak Masuk (Laporan & Saran)\n");
        printf("0. Logout\n");
        pil = inputAngka("Pilih Menu: ");

        switch(pil) {
            case 1: tambahWarga(); break;
            case 2: editWarga(); break;
            case 3: hapusWarga(); break;
            case 4: tampilkanSemua(); break;
            case 5: menuDataBansos(); break;
            case 6: menuKotakMasuk(); break;
        }
    } while (pil != 0);
}
