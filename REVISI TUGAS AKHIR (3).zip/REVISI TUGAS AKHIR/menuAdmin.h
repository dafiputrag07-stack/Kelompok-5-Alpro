#ifndef menu_admin
#define menu_admin

void menuAdmin();

#endif 