#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "struktur.h"
#include "helper.h"
#include "admin.h"

void menuKotakMasuk() {
    int pil;
    do {
        bersihkanLayar();
        printf("=== KOTAK MASUK ADMIN (LAPORAN & SARAN) ===\n");
        printf("1. Lihat Laporan Warga\n");
        printf("2. Lihat Saran Warga\n");
        printf("0. Kembali\n");
        pil = (int)inputAngka("Pilih Kategori: ");

        if (pil == 1) {
            bersihkanLayar();
            printf("--- DAFTAR LAPORAN WARGA %d ---\n", pil);
            int ada = 0;
            for (int i = 0; i < jumlahWarga; i++) {
                if (strcmp(db[i].isiLaporan, "-") != 0) {
                    printf("Dari: %s (NIK: %s)\n", db[i].nama, db[i].nik);
                    printf("Isi Laporan: \"%s\"\n\n", db[i].isiLaporan);
                    ada = 1;
                }
            }
            if (!ada) printf("> Tidak ada laporan.\n");
            printf("Tekan Enter..."); getchar();
        }
        else if (pil == 2) {
            bersihkanLayar();
            printf("--- KOTAK SARAN ---\n");
            int ada = 0;
            for (int i = 0; i < jumlahWarga; i++) {
                if (strcmp(db[i].saranMasukan, "-") != 0) {
                    printf("Dari: %s (NIK: %s)\n", db[i].nama, db[i].nik);
                    printf("Saran: %s\n", db[i].saranMasukan);
                    printf("---------------------------\n");
                    ada = 1;
                }
            }
            if (!ada) printf("Belum ada saran.\n");
            printf("Enter..."); getchar();
        }

    } while (pil != 0);
}

void menuDataBansos() {
    int pil;
    do {
        bersihkanLayar();
        printf("=== DATA BANSOS WARGA ===\n");
        printf("1. Data Prioritas Bansos\n2. Data Non Prioritas Bansos\n0. Kembali\n");
        pil = inputAngka("Pilih: ");

        if (pil == 1) {
            do {
                bersihkanLayar();
                printf("=== DATA PRIORITAS BANSOS (GOL 1 & 2) ===\n");
                printf("1. Lihat Daftar\n2. Cari Warga\n0. Kembali\n");
                pil = inputAngka("Pilih: ");

                if (pil == 1) {
                    bersihkanLayar();
                    printf("| %-20s | %-5s | %-12s |\n", "NAMA", "GOL", "STATUS");
                    printf("-----------------------------------------------\n");
                    for (int i = 0; i < jumlahWarga; i++) {
                        if (db[i].golongan <= 2)
                            printf("| %-20s | %-5d | PRIORITAS |\n", db[i].nama, db[i].golongan);
                    }
                    getchar();
                }
                else if (pil == 2) {
                    cariData();
                    for (int i = 0; i < jumlahWarga; i++) {
                        if (db[i].golongan <= 2)
                            printf(">> %s - Gol %d (Skor %.1f)\n", db[i].nama, db[i].golongan, db[i].skorAkhir);
                    }
                    getchar();
                }
            } while (pil != 0);
            }
        }
        else if (pil == 2) {
            do {
                bersihkanLayar();
                printf("=== DATA NON PRIORITAS BANSOS (GOL 3 - 6) ===\n");
                printf("1. Lihat Daftar\n2. Cari Warga\n0. Kembali\n");
                pil = inputAngka("Pilih: ");

                if (pil == 1) {
                    bersihkanLayar();
                    printf("| %-20s | %-5s | %-12s |\n", "NAMA", "GOL", "STATUS");
                    printf("-----------------------------------------------\n");
                    for (int i = 0; i < jumlahWarga; i++) {
                        if (db[i].golongan >= 2)
                            printf("| %-20s | %-5d | NON PRIORITAS |\n", db[i].nama, db[i].golongan);
                    }
                    getchar();
                }
                else if (pil == 2) {
                    cariData();
                    for (int i = 0; i < jumlahWarga; i++) {
                        if (db[i].golongan >= 2)
                            printf(">> %s - Gol %d (Skor %.1f)\n", db[i].nama, db[i].golongan, db[i].skorAkhir);
                    }
                    getchar();
                }
            } while (pil != 0);
        }
    } while (pil != 0);
}

void sortBySkor(Warga db[], int n) {
    for (int i = 0; i < n - 1; i++) {
        for (int j = 0; j < n - i - 1; j++) {

            if (db[j].skorAkhir < db[j + 1].skorAkhir) {
                Warga temp = db[j];
                db[j] = db[j + 1];
                db[j + 1] = temp;
            }
        }
    }
}

void tampilkanSemua() {
    int pil;
    do {
        bersihkanLayar();
        printf("=== DATA WARGA ===\n");
        printf("1. Tampilkan Semua Data Warga \n2. Cari Data Warga \n0. Kembali\n");
        pil = inputAngka("Pilih: ");

        if (pil == 1) {
            bersihkanLayar();
            sortBySkor(db, jumlahWarga);
            printf("| %-14s | %-20s | %-6s | %-7s |\n", "NIK", "NAMA", "SKOR", "GOL");
            printf("----------------------------------------------------------\n");
            for (int i = 0; i < jumlahWarga; i++)
                printf("| %-14s | %-20s | %-6.1f | %-7d |\n", db[i].nik, db[i].nama, db[i].skorAkhir, db[i].golongan);
            printf("\n Enter..."); getchar();
        } else if (pil == 2) {
                    cariData();
                    lihatDataPribadi();
                    printf("\n Enter..."); getchar();
        }
    } while (pil != 0);
}


