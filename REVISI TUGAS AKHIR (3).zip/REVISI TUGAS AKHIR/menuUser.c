#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "struktur.h"
#include "helper.h"
#include "menuUser.h"
#include "logika.h"
#include "pengguna.h"


void menuUser(int idx) {
    int pil;
    do {
        bersihkanLayar();
        printf("=== HALAMAN WARGA: %s ===\n", db[idx].nama);
        printf("1. Cek Status Bansos Saya\n");
        printf("2. Lapor Kesalahan Data \n");
        printf("3. Kirim Masukan & Saran (Ke Admin)\n");
        printf("4. Lihat Data Pribadi Saya\n");
        printf("0. Logout\n");
        pil = (int)inputAngka("Pilih: ");

        if (pil == 1) {
            printf("\nSkor: %.1f | Golongan: %d\n", db[idx].skorAkhir, db[idx].golongan);
            printf("STATUS: %s\n", (db[idx].golongan <= 2 ? "BERHAK MENERIMA BANSOS" : "TIDAK MENERIMA BANSOS"));
            getchar();
        }
        else if (pil == 2) {
            printf("\n--- KOTAK LAPORAN ---\n");
            printf("Tulis Laporan: ");
            fgets(db[idx].isiLaporan, 200, stdin);
            db[idx].isiLaporan[strcspn(db[idx].isiLaporan, "\n")] = 0;
            simpanFile();
            printf("[v] Laporan terkirim!\n");
            getchar();
        }
        else if (pil == 3) {
            printf("\n--- KOTAK SARAN ---\n");
            printf("Tulis saran: ");
            fgets(db[idx].saranMasukan, 200, stdin);
            db[idx].saranMasukan[strcspn(db[idx].saranMasukan, "\n")] = 0;
            simpanFile();
            printf("[v] Saran terkirim!\n");
            getchar();
        }
        else if (pil == 4) {
            lihatDataPribadi(idx);
        }

    } while (pil != 0);
}


