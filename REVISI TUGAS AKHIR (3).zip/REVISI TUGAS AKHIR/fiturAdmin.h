#ifndef fitur_admin
#define fitur_admin

void tambahWarga();
void editWarga();
void hapusWarga();

#endif 