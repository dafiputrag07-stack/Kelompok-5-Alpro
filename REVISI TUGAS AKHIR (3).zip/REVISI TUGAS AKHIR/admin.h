#ifndef admin
#define admin

void menuKotakMasuk();
void menuDataBansos();
void tampilkanSemua();

#endif 