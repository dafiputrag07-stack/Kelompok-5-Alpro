#ifndef menu_user
#define menu_user

void menuUser(int idx);

#endif