#ifndef helper
#define helper

void bersihkanLayar();
long inputAngka(char *pesan);
void cariData();

#endif
