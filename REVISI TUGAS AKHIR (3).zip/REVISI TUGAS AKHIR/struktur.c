#include "struktur.h"

Warga db[100];
int jumlahWarga = 0;
const char *FILE_NAME = "dataWarga.txt";
