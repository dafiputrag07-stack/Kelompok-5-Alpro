#ifndef pengguna
#define pengguna

void lihatDataPribadi(int idx);

#endif 