#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "struktur.h"
#include "helper.h"

void bersihkanLayar() {
#ifdef _WIN32
    system("cls");
#else
    system("clear");
#endif
}

long inputAngka(char *pesan) {
    char buffer[100];
    long angka;
    int valid = 0;
    while(!valid) {
        printf("%s", pesan);
        fgets(buffer, 100, stdin);
        char *endptr;
        angka = strtol (buffer, &endptr, 10);
        if (endptr == buffer || (*endptr != '\n' && *endptr != '\0')) {
            printf("[!] Error: Harap masukkan angka yang valid!\n");
        } else valid = 1;
    }
    return angka;
}

void cariData() {
    char cariDataWarga[50];
        printf("Nama/NIK: ");
        fgets(cariDataWarga, 50, stdin);
        cariDataWarga[strcspn(cariDataWarga, "\n")] = 0;
        for (int i = 0; i < jumlahWarga; i++) {
            if (strstr(db[i].nama, cariDataWarga) != NULL || strcmp(db[i].nik, cariDataWarga) == 0){
            }
        }
    }
